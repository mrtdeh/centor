#!/bin/bash

# Get input parameters

for service_name in "$@"
do
   
	service_path="/etc/systemd/system/$service_name.service"

	# Check if service file exists, if not exit with error message
	if [ ! -f $service_path ]; then
	  echo "Service file not found."
	  exit 1
	fi

	execCmd=$(grep "ExecStart=" $service_path)

	if grep -q "\-debug" $service_path; then
	    echo "Remove switch debug from $service_name"
	    sed -i "s/-debug//" $service_path
	else
	    echo "Add switch debug to $service_name"
	    sed -i "s~^ExecStart=.*~$execCmd -debug~" $service_path
	fi

done

# Add switch to ExecStart in service file

# Reload systemd daemon to apply changes
systemctl daemon-reload

# Restart the service
for service_name in "$@"
do
	systemctl restart "$service_name"
done
