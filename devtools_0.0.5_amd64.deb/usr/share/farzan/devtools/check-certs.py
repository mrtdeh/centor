#!/bin/python3

import subprocess
import os


# ==============================================================

cert_file_path = '/opt/certs/server.crt'
key_file_path = '/opt/certs/server.key'
ca_file_path = '/opt/certs/ca.crt'


# ==============================================================



def check_private_public(cert_path, key_path):
    cmd_cert = f'openssl x509 -pubkey -in {cert_path} -noout | openssl md5'
    cmd_key = f'openssl pkey -pubout -in {key_path} | openssl md5'

    try:

        result_cert = subprocess.run(cmd_cert, shell=True, capture_output=True, text=True)
        cert_hash = result_cert.stdout.strip()


        result_key = subprocess.run(cmd_key, shell=True, capture_output=True, text=True)
        key_hash =  result_key.stdout.strip()

        if (cert_hash == key_hash):
            print("match:OK")
        else:
            print("match:Err")

    except subprocess.CalledProcessError as e:
        print("Error:", e)

def check_ca_public(cert_path, ca_path):
    cmd = f'openssl verify -verbose -CAfile {ca_path} {cert_path}'
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if "OK" in result.stdout.strip():
            print("cert:OK")
        else:
            print("cert:Err")
    except subprocess.CalledProcessError as e:
        print("Error:", e)

def check_ca(ca_path):
    cmd = f'openssl x509 -in {ca_path} -noout -text | grep "CA:TRUE"'
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            print("ca:OK")
        else:
            print("ca:Err")
    except subprocess.CalledProcessError as e:
        print("Error:", e)



def check_file_existence(file_path):
    if not os.path.isfile(file_path):
        print(f"The file '{file_path}' does not exist.")



check_file_existence(ca_file_path)
check_file_existence(cert_file_path)
check_file_existence(key_file_path)

check_private_public(cert_file_path, key_file_path)
check_ca_public(cert_file_path, ca_file_path)
check_ca(ca_file_path)
