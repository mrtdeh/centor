#!/bin/python3

import subprocess
import re
import json
from datetime import datetime, date
# ==================================  Configuration Area ========================================

services = [

    ("central-management",  	3000, 	"service"),
    ("asset-api",    		    8000, 	"service"),
    ("asset-updater",    	    0, 	    "service"),
    ("ntp-management",      	8050, 	"service"),
    ("ipsec-management",    	8010, 	"service"),
    ("setting-management",    	8030, 	"service"),
    ("logman",    		        0, 	    "service"),
    ("elasticsearch",    	    9200, 	"service"),
    ("nginx",    		        0, 	    "service"),
    ("mariadb",    		        3306, 	"container"),
    ("redis",    		        6379, 	"container"),

]


# ==================================  Configuration Area ========================================



def get_service_uptime(service_name):
    try:
        result = subprocess.run(['systemctl', 'show', '-p', 'ActiveEnterTimestamp', service_name], capture_output=True, text=True)
        output = result.stdout.strip().split('=')
        if len(output) == 2:
            timestamp_str = output[1]
            timestamp = datetime.strptime(timestamp_str, "%a %Y-%m-%d %H:%M:%S %z").time()

            a = datetime.combine(date.today(), timestamp)
            b = datetime.combine(date.today(), datetime.now().time() )
            uptime = b - a

            if uptime is not None:
                return format_uptime(uptime)
    except :
        pass

    return "-"

def get_docker_service_uptime(service_name):
    try:
        result = subprocess.run(['docker', 'inspect', '--format', '{{.State.StartedAt}}', service_name], capture_output=True, text=True)
        output = result.stdout.strip()
        if output:
            output = output[:-4]+"Z" #fix "does not match format" error
            start_time = datetime.strptime(output, "%Y-%m-%dT%H:%M:%S.%fZ")
            uptime = datetime.now() - start_time

            if uptime is not None:
                return format_uptime(uptime)
                
    except :
        pass

    return "-"

def format_uptime(uptime):
    seconds = uptime.total_seconds()
    days = seconds // (24 * 3600)
    hours = (seconds % (24 * 3600)) // 3600
    minutes = (seconds % 3600) // 60
    seconds = seconds % 60

    uptime_str = ""
    if days > 0:
        uptime_str += f"{msg_bold(int(days))}d,"
    if hours > 0:
        uptime_str += f"{msg_bold(int(hours))}h,"
        if days > 0:
            return uptime_str[:-1]
    if minutes > 0:
        uptime_str += f"{msg_bold(int(minutes))}m,"
        if hours > 0:
            return uptime_str[:-1]
    uptime_str += f"{msg_bold(int(seconds))}s"
    if minutes <= 0 and hours <= 0:
        uptime_str=msg_bold("0")+"m,"+uptime_str

    return uptime_str



def test_port_type(port):
    portmsg = msg_bold(str(port))+":"

    if (port == 0):
        return "-"

    cmd = "netstat -an | grep LISTEN | grep -w {}".format(port)
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)

    if result.stdout:
        if "127.0.0.1:{}".format(port) in result.stdout:
            return portmsg+msg_ok("Local")
        else:
            return portmsg+msg_warn("Global")

    return portmsg+"-"


def is_service_exist(service):
    cmd = f"systemctl list-units | grep -w {service}.service"
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    output = result.stdout.strip()
    return output != ""


def check_service_status(service):
    
    if not is_service_exist(service):
        return "-",""

    cmd = f"systemctl is-active {service}"
    result = subprocess.run(cmd.split(), capture_output=True)
    status = result.stdout.decode().strip()
    
    cmd = f"grep -E 'ExecStart.*' /etc/systemd/system/{service}.service"
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    switches = result.stdout.strip()
    switches = re.findall('\s-.*', switches)
    switches = switches[0] if len(switches) > 0 else ''
    
    if (status == "active"):
        status = msg_ok("Active")
    elif (status == "activating"):
        status = msg_warn("Restarting")
    else:
        status = msg_err(str.title(status))

    return status, switches

    


def get_container_status(container_name):
    command = f"docker inspect {container_name}"
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    output = result.stdout.strip()
    
    if result.returncode == 0:
        container_info = json.loads(output)[0]
        container_state = container_info["State"]
        if container_state["Running"]:
            return msg_ok("Active")
        elif container_state["Restarting"]:
            return msg_warn("Restarting")
        else:
            return msg_err("Inactive")
    else:
        return "-"



def generate_service_table(services):
    header = ["Service", "Status", "Port Type","Up Time", "Switches"]
    rows = []
    for service, port, type in services:
        status =  switches = uptime = ""
        port_type = test_port_type(port)
        if (type == "container"):
            status = get_container_status(service)
            uptime = get_docker_service_uptime(service)
        else:
            status,  switches = check_service_status(service)
            uptime = get_service_uptime(service)
            
        if status == "-":
            port_type = "-"

        rows.append([msg_bold(service), status, port_type,uptime, switches])
    print_table(header, rows)



def print_table(header, rows):
    rows.insert(0,["---"] * len(header))
    rows.insert(0,header)
    col_width = [max(len(str(cleanStr(row[i]))) for row in rows) for i in range(len(header))]
        
    for row in rows:
        row_str = ""
        for i in range(len(header)):
            fcol = cleanStr(row[i])
            spaceNum = ((col_width[i]-len(fcol)))
            if (row[i] == "---"):
                row_str += "-"*(spaceNum+3) + " | " 
            else:
                row_str += str(row[i])+" "*spaceNum + " | "
        print(row_str[:-3])


def cleanStr(str):
    if str is None:
        return "-"
    str = str.replace(bcolors.OKGREEN,'')
    str = str.replace(bcolors.WARNING,'')
    str = str.replace(bcolors.FAIL,'')
    str = str.replace(bcolors.ENDC,'')
    str = str.replace(bcolors.BOLD,'')
    return str



class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[32m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
def msg_ok(msg):
    return bcolors.OKGREEN  + str(msg) + bcolors.ENDC 
def msg_warn(msg):
    return bcolors.WARNING + str(msg) + bcolors.ENDC
def msg_err(msg):
    return bcolors.FAIL + str(msg) + bcolors.ENDC
def msg_info(msg):
    return bcolors.OKCYAN + str(msg) + bcolors.ENDC
def msg_bold(msg):
    return bcolors.BOLD + str(msg) + bcolors.ENDC




generate_service_table(services)